// Package telemetry is a made-up module for the whybumped examples.
package telemetry
