// Package payclient is a made-up module for the whybumped examples.
package payclient
