// Package textutil is a made-up module for the whybumped examples.
package textutil
