// Package httpkit is a made-up module for the whybumped examples.
package httpkit
