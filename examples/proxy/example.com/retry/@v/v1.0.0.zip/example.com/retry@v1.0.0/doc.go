// Package retry is a made-up module for the whybumped examples.
package retry
